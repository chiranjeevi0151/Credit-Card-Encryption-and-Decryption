# config.py

PASSWORD = "strong_password"  # Change this to a secure password
            